#include <utility>
#include <stdlib.h>
#include <time.h>
#include "GameModel.h"
#include "position.h"
#include<iostream>
using namespace std;

GameModel::GameModel()
{

}

void GameModel::startGame()
{
    // 初始7*7棋盘以及评分
    inimap();
    iniscore();
    // 玩家下为true,电脑下为false
    playerFlag = false;
}
void GameModel::inimap(){
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            gamemap[i][j]=0;
}
void GameModel::iniscore(){
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            score[i][j]=0;
}
void GameModel::updateGameMap(int x,int y)
{cout<<x<<" "<<y<<endl;
    if (playerFlag)
        gamemap[x][y]=1;  //white 1
    else
        gamemap[x][y]=-1;  //black -1
    playerFlag=!playerFlag;// 换成另一方下棋
}

void GameModel::actionByPerson(int x, int y)
{
    updateGameMap(x,y);
}

void GameModel::actionByAI()
{
//    for(int i=2;i<=7;i++){
//        cout<<" insdc"<<endl;
//        for(int j=2;j<=7;j++){
//            if(gamemap[i][j])
//                break;

//            if((i==7)&&(j==7)){
//                updateGameMap(4,4);
//                cout<<"up"<<endl;   //如果是第一步，选中间的地方开局
//                return;
//            }
//        }
//    }

    calculateScore();// 计算评分

    // 从评分中找出最大分数的位置
    int maxScore = 0;
    vector<position> max_point;
    position point;

    for(int i=2;i<=7;i++)
        for(int j=2;j<=7;j++)
            if(!gamemap[i][j]){//如果棋盘上没有落子
                if(score[i][j]>maxScore){
                    max_point.clear();
                    point.setX(i);
                    point.setY(j);
                    max_point.push_back(point);
                    maxScore=score[i][j];  //记录最大分数位置以及最大分数
                }
                else if(score[i][j]==maxScore){
                    point.setX(i);
                    point.setY(j);
                    cout<<i<<" "<<j<<endl;
                    max_point.push_back(point);
                }
            }

    srand((unsigned)time(0));   // 实现若有多个点均可选择时的随机落子
    int which=rand()%max_point.size();

    int clickX=(max_point[which].getX());
    int clickY=(max_point[which].getY());

    updateGameMap(clickX, clickY);//更新落子点
}

void GameModel::calculateScore()
{
    iniscore();
    int empty=8;
    int virtualmap[9][9]={0};   //虚拟数组用于模拟某步之后的棋局
    for(int i=0;i<9;i++)
        for(int j=0;j<9;j++)
            virtualmap[i][j]=gamemap[i][j];//初始化虚拟数组
    for(int i=2;i<7;i++){
        for(int j=2;j<7;j++){
            if(!virtualmap[i][j])
            virtualmap[i][j]=-1;//将虚拟map变成下了这一步之后的情景，为黑子
            //依次判断每个方位是什么棋局
          
            if(virtualmap[i-1][j]==virtualmap[i][j]){//左
                if(virtualmap[i-1][j]==-virtualmap[i][j]) empty--;
                if((virtualmap[i-2][j]==virtualmap[i][j])||(virtualmap[i+1][j]==virtualmap[i][j]))  score[i][j]+=100000;//三子
                else if((virtualmap[i-2][j]&&virtualmap[i+1][j])==0)  score[i][j]+=1000;   //活二
                else if((virtualmap[i-2][j]+virtualmap[i+1][j])==-virtualmap[i][j])  score[i][j]+=100;   //冲二
            }
            if(virtualmap[i-1][j-1]==virtualmap[i][j]){//左上
                if(virtualmap[i-1][j-1]==-virtualmap[i][j]) empty--;
                if((virtualmap[i-2][j-2]==virtualmap[i][j])||(virtualmap[i+1][j+1]==virtualmap[i][j]))  score[i][j]+=100000;//三子
                else if((virtualmap[i-2][j-2]&&virtualmap[i+1][j+1])==0)  score[i][j]+=1000;   //活二
                else if((virtualmap[i-2][j-2]+virtualmap[i+1][j+1])==-virtualmap[i][j])  score[i][j]+=100;   //冲二
            }
            if(virtualmap[i][j-1]==virtualmap[i][j]){//上
                if(virtualmap[i][j-1]==-virtualmap[i][j]) empty--; 
                if((virtualmap[i][j-2]==virtualmap[i][j])||(virtualmap[i][j+1]==virtualmap[i][j]))  score[i][j]+=10000;
                else if((virtualmap[i][j-2]&&virtualmap[i][j+1])==0)  score[i][j]+=1000;   //活二
                else if((virtualmap[i][j-2]+virtualmap[i][j+1])==-virtualmap[i][j])  score[i][j]+=100;   //活二
            }
            if(virtualmap[i+1][j-1]==virtualmap[i][j]){//右上
                if(virtualmap[i+1][j-1]==-virtualmap[i][j]) empty--;
                if((virtualmap[i+2][j-2]==virtualmap[i][j])||(virtualmap[i-1][j+1]==virtualmap[i][j]))  score[i][j]+=10000;
                else if((virtualmap[i+2][j-2]&&virtualmap[i-1][j+1])==0)  score[i][j]+=1000;
                else if((virtualmap[i+2][j-2]+virtualmap[i-1][j+1])==-virtualmap[i][j])  score[i][j]+=100;
            }
            if(virtualmap[i+1][j]==virtualmap[i][j]){//右
                if(virtualmap[i+1][j]==-virtualmap[i][j]) empty--;
                if((virtualmap[i+2][j]==virtualmap[i][j])||(virtualmap[i-1][j]==virtualmap[i][j]))  score[i][j]+=10000;
                else if((virtualmap[i+2][j]&&virtualmap[i-1][j])==0)  score[i][j]+=1000;
                else if((virtualmap[i+2][j]+virtualmap[i-1][j])==-virtualmap[i][j])  score[i][j]+=100;
            }
            if(virtualmap[i+1][j+1]==virtualmap[i][j]){//右下
                if(virtualmap[i+1][j+1]==-virtualmap[i][j]) empty--;
                if((virtualmap[i+2][j+2]==virtualmap[i][j])||(virtualmap[i-1][j-1]==virtualmap[i][j]))  score[i][j]+=10000;
                else if((virtualmap[i+2][j+2]&&virtualmap[i-1][j-1])==0)  score[i][j]+=1000;
                else if((virtualmap[i+2][j+2]+virtualmap[i-1][j-1])==-virtualmap[i][j])  score[i][j]+=100;
            }
        
            if(virtualmap[i][j+1]==virtualmap[i][j]){//下
                if(virtualmap[i][j+1]==-virtualmap[i][j]) empty--;
                if((virtualmap[i][j+2]==virtualmap[i][j])||(virtualmap[i][j-1]==virtualmap[i][j]))  score[i][j]+=10000;
                else if((virtualmap[i][j+2]&&virtualmap[i][j-1])==0)   score[i][j]+=1000;
                else if((virtualmap[i][j+2]+virtualmap[i][j-1])==-virtualmap[i][j])   score[i][j]+=100;
            }
        
            if(virtualmap[i-1][j+1]==virtualmap[i][j]){//左下
                if(virtualmap[i-1][j+1]==-virtualmap[i][j]) empty--;
                if((virtualmap[i-2][j+2]==virtualmap[i][j])||(virtualmap[i+1][j-1]==virtualmap[i][j]))  score[i][j]+=10000;
                else if((virtualmap[i-2][j+2]&&virtualmap[i+1][j-1])==0)   score[i][j]+=1000;
                else if((virtualmap[i-2][j+2]+virtualmap[i+1][j-1])==-virtualmap[i][j])   score[i][j]+=100;
            }
            
            if((empty==8)&&(score[i][j]==0))  score[i][j]+=10;   //空位为零
            
        }
    }
}

bool GameModel::isWin(int x,int y)
{
    if(gamemap[x-1][y]==gamemap[x][y])//左
        if((gamemap[x+1][y]==gamemap[x][y])||(gamemap[x-2][y]==gamemap[x][y]))  return true;

    if(gamemap[x-1][y-1]==gamemap[x][y])//左上
        if((gamemap[x-2][y-2]==gamemap[x][y])||(gamemap[x+1][y+1]==gamemap[x][y]))  return true;

    if(gamemap[x][y-1]==gamemap[x][y])//上
        if((gamemap[x][y-2]==gamemap[x][y])||(gamemap[x][y+1]==gamemap[x][y]))  return true;

    if(gamemap[x+1][y-1]==gamemap[x][y])//右上
        if((gamemap[x+2][y-2]==gamemap[x][y])||(gamemap[x-1][y+1]==gamemap[x][y]))  return true;

    if(gamemap[x+1][y]==gamemap[x][y])//右
        if((gamemap[x+2][y]==gamemap[x][y])||(gamemap[x-1][y]==gamemap[x][y]))  return true;

    if(gamemap[x+1][y+1]==gamemap[x][y])//右下
        if((gamemap[x+2][y+2]==gamemap[x][y])||(gamemap[x-1][y-1]==gamemap[x][y]))  return true;

    if(gamemap[x][y+1]==gamemap[x][y])//下
        if((gamemap[x][y+2]==gamemap[x][y])||(gamemap[x][y-1]==gamemap[x][y]))  return true;

    if(gamemap[x-1][y+1]==gamemap[x][y])//左下
        if((gamemap[x-2][y+2]==gamemap[x][y])||(gamemap[x+1][y-1]==gamemap[x][y]))  return true;

    return false;   //若都不满足,返回false
}

bool GameModel::isDeadGame()   //判断是否死局了
{
    for(short i=2;i<7;i++){
        for(short j=2;j<7;j++){
            if(!gamemap[i][j]) return false;  //还有空位
        }
    }
    return true;
}


#ifndef MW2_H
#define MW2_H

#include <QMainWindow>

namespace Ui {
class mw2;
}

class mw2 : public QMainWindow
{
    Q_OBJECT

public:
    explicit mw2(QWidget *parent = 0);
    ~mw2();

private:
    Ui::mw2 *ui;
};

#endif // MW2_H

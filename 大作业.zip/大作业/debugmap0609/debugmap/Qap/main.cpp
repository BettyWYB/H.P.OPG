#include "mw1.h"
#include "world.h"
#include "logindlg.h"
#include <QApplication>
#include <fstream>
#include<QLabel>
#include <iostream>
#include "mainwindow.h"
using namespace std;
fstream file;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   // MW1 mw1;
    MainWindow w;

    LoginDlg dlg;
    // 建立自己新建的类的对象dlg
    if(dlg.exec() == QDialog::Accepted) // 利用Accepted返回值判断按钮是否被按下
    {
         w.show();
        int st;
        file.open(":/map.txt",ios::in);
//        if(file.is_open()) cout<<" hbjhgdj"<<endl;
        file>>st;   //首先获取文件中第一行的当前世界所需画面
//        cout<<st<<endl;
       // mw1.show();
       // mw1.setState(st);
       file.close();
       return a.exec();               // 程序一直执行，直到主窗口关闭
   }
       else return 0;            //如果没被按下，则不会进入主窗口，整个程序结束运行


    //return a.exec();
}

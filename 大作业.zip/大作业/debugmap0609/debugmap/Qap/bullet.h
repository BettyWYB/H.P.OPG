#ifndef BULLET_H
#define BULLET_H
#include "rpgobj.h"
#include <QMediaPlayer>

class Bullet:public RPGObj
{
public:
    Bullet(){}
    void initObj(string type,string route);
    void sets(int S){this->s=S;}
    int gets(){return this->s;}

    void setinix(int x){inix=x;}
    int getinix(){return inix;}

    void setiniy(int y){iniy=y;}
    int getiniy(){return iniy;}

    void setstate(int x){state=x;}
    int getstate(){return state;}

    int getdistance(){return distance;}
    void playsound(){
        QMediaPlayer * music = new QMediaPlayer;
        music->setMedia(QUrl::fromLocalFile("C:\\Users\\win\\Desktop\\debugmap0609\\sf\\mofa.wav"));
        music->setVolume(50);
        music->play();
    }

protected:
    int inix,iniy;          //初始坐标
    int s;                  //
    int distance;           //攻击距离
    int state;              //攻击的类型             //1是普通攻击  2是skill
};

#endif // BULLET_H

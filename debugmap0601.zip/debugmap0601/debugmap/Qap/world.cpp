#include "world.h"
#include "player.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include "rpgobj.h"
#include "bullet.h"
#include "monster.h"
#include <vector>




void World::initWorld(string mapFile){
    //读入地图文件，地图文件样例：
    //1（这是第几幅画面的标识）
    //player 5（x坐标） 5（y坐标） 90（当前血量） 80（当前蓝量） 20（当前经验） 3（当前等级）
    //bullet 4（x坐标） 6（y坐标） 2(当前已经过的距离) 1（状态，大招或是小招）
    //monster 6（x坐标） 8（y坐标） 50（当前血量）
    //RPGOBJ  //标识符
    //flower 7（x坐标） 5（y坐标）
    //EOF(文件结束标识)
    extern fstream file;
    string input;
    int pos_x,pos_y,blood,power,exp,rank,now_dis,state;
    file.open(mapFile.c_str(),ios::trunc);
    if(file.is_open())  cout<<"1"<<endl;
    else cout<<"0"<<endl;
    file>>input;             //滤过第一个state
    file>>input;            //首先录入player信息
    this->_player.initObj(input,":/:/player.png");
    file>>pos_x>>pos_y;
    this->_player.setPosX(pos_x);  //录入横坐标
    this->_player.setPosY(pos_y);  //录入纵坐标
    ary[_player.getPosX()][_player.getPosY()+1]=4;  //初始化二维数组为4
    file>>blood>>power>>exp>>rank;  //录入血量，蓝量，经验，等级
    this->_player.blood=blood;
    this->_player.power=power;
    this->_player.exp=exp;
    this->_player.rank=rank;

    file>>input;
    Bullet bullet;
    while(input=="bullet"){//如果检测到正在录入子弹信息   重复录入
        file>>pos_x>>pos_y>>now_dis>>state;
        if(state==1)
            bullet.initObj("biu",":/:/feibiao.png");
        else
            bullet.initObj("Biu",":/:/feibiao.png");
        bullet.inibullet(pos_x,pos_y,now_dis,state);
        this->_biu.push_back(bullet);
        file>>input;
    }
    Monster monster;
    while(input=="monster"){//如果检测到正在录入怪兽信息   重复录入
        monster.initObj(input,":/:/TileB.png");
        file>>pos_x>>pos_y>>blood;
        monster.setPosX(pos_x);//由于inimonster函数还没有实现，只能强行初始化每一个数据~~
        monster.setPosY(pos_y);
        monster.blood=blood;
        ary[pos_x][pos_y+1]=3;//初始化二维数组为3
        this->monsters.push_back(monster);
    }
    RPGObj obj;
    if(input=="RPGOBJ"){//判断标识符
        file>>input;
        while(input!="EOF"){
            if(input=="fruit"){
                obj.initObj("fruit",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=2;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(file=="stone"){
                obj.initObj("stone",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else if(file=="well"){
                obj.initObj("well",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
        }
    }
    if(input=="EOF") file.close();

    //二维数组为0，说明什么也没有，为1不可过，为2可吃,3为怪物 遇见要掉血,4是玩家
/*
    this->_player.initObj("player",":/:/player.png");
    this->_player.setPosX(5);
    this->_player.setPosY(5);
    ary[5][5]=4;


    this->_monster.initObj("monster",":/:/TileB.png");
    this->_monster.setPosX(10);
    this->_monster.setPosY(10);
   // ary[10][10]=3;
    monsters.push_back(_monster);

    const char * out=mapFile.c_str();
    ifstream fin ;
    fin.open(out);
    string zifu;
    int a,b,c;
    while(fin){

        fin>>zifu;
        fin>>a>>b>>c;
        RPGObj  obj;
        obj.initObj(zifu,":/:/TileB.png");
        obj.setPosX(a);
        obj.setPosY(b);
        ary[a][b]= c;
        this->_objs.push_back(obj);
    }
    fin.close();
*/

}


void World::show(QPainter * painter){
    /*vector<RPGObj>::iterator it;
    for(it=this->_objs.begin(); it!=this->_objs.end();it++){

            (*it).show(painter);
    }*/
    for(int i=0;i<_objs.size();i++)
    {
        if(_objs[i]._exsistence==false)
        {
            ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
            vector<RPGObj>::iterator de;
            de=_objs.begin()+i;
            _objs.erase(de);
        }
        _objs[i].show(painter);
    }

    for(int i=0;i<monsters.size();i++)                           //加入血量
    {

        if(monsters[i]._exsistence==false)
        {
            ary[monsters[i].getPosX()][monsters[i].getPosY()]=0;
            vector<Monster>::iterator se;
            se=monsters.begin()+i;
            monsters.erase(se);
        }
        monsters[i].showinfo(painter);
        monsters[i].show(painter);
    }

    for(int i=0;i<_biu.size();i++)
    {
        if(_biu[i]._exsistence==false)
        {
            ary[_biu[i].getPosX()][_biu[i].getPosY()]=0;
            vector<Bullet>::iterator ae;
            ae=_biu.begin()+i;
            _biu.erase(ae);
        }
        _biu[i].show(painter);
    }
    if(_player.blood>0)
    this->_player.show(painter);            //加入血量
}

void World::handlePlayerMove(int direction, int steps){


    switch (direction){
        case 1:
            _player.setdir(1);
            if(ary[_player.getPosX()][_player.getPosY()]==1)
               this->_player.move(direction,steps-1) ;
            else if(ary[_player.getPosX()][_player.getPosY()]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY())
                    {
                        _objs[i]._exsistence=false;
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()]=4;
                this->_player.move(direction,steps);
                if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                 if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                 if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                 if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
            }
            else if(ary[_player.getPosX()][_player.getPosY()]==3){
                this->_player.move(direction,steps-1);
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 2:
        _player.setdir(2);
            //this->_pos_y += steps;
            if(ary[_player.getPosX()][_player.getPosY()+2]==1)
                this->_player.move(direction,steps-1);
            else if(ary[_player.getPosX()][_player.getPosY()+2]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY()+2)
                    {
                        _objs[i]._exsistence=false;
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()+2]=4;
                this->_player.move(direction,steps);
                if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                 if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                 if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                 if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
            }

            else if(ary[_player.getPosX()][_player.getPosY()+2]==3){
                this->_player.move(direction,steps-1);
                //掉血
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()+2]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 3:
        _player.setdir(3);
            //this->_pos_x -= steps;
            if(ary[_player.getPosX()-1][_player.getPosY()+1]==1)
                this->_player.move(direction,steps-1);
            else if(ary[_player.getPosX()-1][_player.getPosY()+1]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()-1&&_objs[i].getPosY()==_player.getPosY()+1)
                    {
                        _objs[i]._exsistence=false;
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()-1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                 if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                 if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                 if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
            }

            else if(ary[_player.getPosX()-1][_player.getPosY()+1]==3){
                this->_player.move(direction,steps-1);
                //掉血
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()-1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 4:
        _player.setdir(4);
            //this->_pos_x += steps;
        //遇见石头
            if(ary[_player.getPosX()+1][_player.getPosY()+1]==1)            //下个位置
                this->_player.move(direction,steps-1);
        //遇见吃的
            else if(ary[_player.getPosX()+1][_player.getPosY()+1]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()+1&&_objs[i].getPosY()==_player.getPosY()+1)
                    {
                        _objs[i]._exsistence=false;
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()+1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                 if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                 if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                 if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
            }
        //遇见怪物
            else if(ary[_player.getPosX()+1][_player.getPosY()+1]==3){
                this->_player.move(direction,steps-1);
                //掉血
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()+1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }
            break;
    }
}

void World::snakemove(int x,int y)
{
    if(ary[x][y+1]==0)
    {
        Monster obl;
        obl.initObj("monster",":/:/TileB.png");
        obl.setPosX(x);
        obl.setPosY(y);
        obl._exsistence=true;
        ary[x][y+1]=3;
        if(monsters.size()<10)
        this->monsters.push_back(obl);

    }

}

void World::voldattack(int x, int y,int Dir)
{
    Bullet ss;
    ss.initObj("biu",":/:/feibiao.png");
    ss.setdir(Dir);
    switch(ss.getdir())
    {
    case 1:
        ss.setPosX(x);
        ss.setPosY(y-1);
        break;
    case 2:
        ss.setPosX(x);
        ss.setPosY(y+2);
        break;
    case 3:
        ss.setPosX(x-1);
        ss.setPosY(y+1);
        break;
    case 4:
        ss.setPosX(x+1);
        ss.setPosY(y+1);
        break;
    }
    ss.inibullet(x,y,0,1);
    _biu.push_back(ss);
}

void World::handlevold(int direction,int steps){
    //this->_monster.move(direction, steps);
    // vold move in routine
    for(int i=0;i<monsters.size();i++)
    {
        switch ((direction*(i+1))%4+1){
            case 1:
                monsters[i].setdir(1);
                if(_player.getPosX()==monsters[i].getPosX()&&_player.getPosY()<monsters[i].getPosY())
                {
                    voldattack(monsters[i].getPosX(),monsters[i].getPosY(),1);
                }
                if(ary[monsters[i].getPosX()][monsters[i].getPosY()]==1||ary[monsters[i].getPosX()][monsters[i].getPosY()]==3||ary[monsters[i].getPosX()][monsters[i].getPosY()]==4)
                   this->monsters[i].move(1,steps-1) ;
                else
                {
                    this->monsters[i].setary0(ary);
                    this->monsters[i].move(1 ,steps);
                    this->monsters[i].setary3(ary);
                }
                break;
            case 2:
             monsters[i].setdir(2);
             if(_player.getPosX()==monsters[i].getPosX()&&_player.getPosY()>monsters[i].getPosY())
             {
                voldattack(monsters[i].getPosX(),monsters[i].getPosY(),2);
             }
                //this->_pos_y += steps;
                if(ary[monsters[i].getPosX()][monsters[i].getPosY()+2]==1||ary[monsters[i].getPosX()][monsters[i].getPosY()+2]==3||ary[monsters[i].getPosX()][monsters[i].getPosY()+2]==4)
                    this->monsters[i].move(2,steps-1);
                else
                    {
                        this->monsters[i].setary0(ary);
                        this->monsters[i].move(2 ,steps);
                        this->monsters[i].setary3(ary);
                    }
                break;
            case 3:
             monsters[i].setdir(3);
             if(_player.getPosX()<monsters[i].getPosX()&&_player.getPosY()==monsters[i].getPosY())
             {
                 voldattack(monsters[i].getPosX(),monsters[i].getPosY(),3);
             }
                //this->_pos_x -= steps;
                if(ary[monsters[i].getPosX()-1][monsters[i].getPosY()+1]==1||ary[monsters[i].getPosX()-1][monsters[i].getPosY()+1]==3||ary[monsters[i].getPosX()-1][monsters[i].getPosY()+1]==4)
                    this->monsters[i].move(3,steps-1);
                else
                {
                    this->monsters[i].setary0(ary);
                    this->monsters[i].move(3 ,steps);
                    this->monsters[i].setary3(ary);
                }
                break;
            case 4:
             monsters[i].setdir(4);
             if(_player.getPosX()>monsters[i].getPosX()&&_player.getPosY()==monsters[i].getPosY())
             {
                 voldattack(monsters[i].getPosX(),monsters[i].getPosY(),4);
             }
                //this->_pos_x += steps;
                if(ary[monsters[i].getPosX()+1][monsters[i].getPosY()+1]==1||ary[monsters[i].getPosX()+1][monsters[i].getPosY()+1]==3||ary[monsters[i].getPosX()+1][monsters[i].getPosY()+1]==4)
                    this->monsters[i].move(4,steps-1);
                else
                {
                    this->monsters[i].setary0(ary);
                    this->monsters[i].move(4 ,steps);
                    this->monsters[i].setary3(ary);
                }
                break;
        }
    }
}

void World::Drugrand(int x,int y)
{
    if(ary[x][y]==0)
    {
        RPGObj obk;
        obk.initObj("fruit",":/:/TileB.png");
        obk.setPosX(x);
        obk.setPosY(y);
        obk._exsistence=true;
        ary[x][y]=2;
        this->_objs.push_back(obk);
    }


}

void World::playerattack()
{
    Bullet Biu;
    Biu.initObj("biu",":/:/feibiao.png");
    Biu.setdir(_player.getdir());
    switch(Biu.getdir())
    {
    case 1:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY());
        break;
    case 2:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+2);
        break;
    case 3:
        Biu.setPosX(_player.getPosX()-1);
        Biu.setPosY(_player.getPosY()+1);
        break;
    case 4:
        Biu.setPosX(_player.getPosX()+1);
        Biu.setPosY(_player.getPosY()+1);
        break;
    }
    Biu.inibullet(_player.getPosX(),_player.getPosY(),0,1);
    _biu.push_back(Biu);

}

void World::playerskill()
{
    Bullet Biu;
    Biu.initObj("Biu",":/:/feibiao.png");         //技能
    Biu.setdir(_player.getdir());
    switch(Biu.getdir())
    {
    case 1:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY());
        //应用不同的图像
        Biu._pic=Biu.Dir[0][0].copy(0,0,32,32);             //上
        break;
    case 2:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+2);
        Biu._pic=Biu.Dir[1][0].copy(0,0,32,32);             //下
        break;
    case 3:
        Biu.setPosX(_player.getPosX()-1);
        Biu.setPosY(_player.getPosY()+1);
        Biu._pic=Biu.Dir[2][0].copy(0,0,32,32);             //左
        break;
    case 4:
        Biu.setPosX(_player.getPosX()+1);
        Biu.setPosY(_player.getPosY()+1);
        Biu._pic=Biu.Dir[3][0].copy(0,0,32,32);             //右
        break;
    }
    Biu.inibullet(_player.getPosX(),_player.getPosY(),0,2);
    _biu.push_back(Biu);

}
/////////////////////////////////////子弹遇见人消失  打怪物或人掉血
void World::bulletfly()
{
    for(int i=0;i<_biu.size();i++)
    {
        _biu[i].sets(_biu[i].gets()+1);
        switch(_biu[i].getdir())
        {
        case 1:
           _biu[i].setPosY(_biu[i].getPosY()-1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3)
            {
                                               //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if(monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);                   //怪物血为0 消失
                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    //TODO
                    //此处应添加game over图像等或者使用复活药水
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        case 2:
            _biu[i].setPosY(_biu[i].getPosY()+1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3)
            {
                                                //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if(monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);
                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        case 3:
            _biu[i].setPosX(_biu[i].getPosX()-1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3)
            {
                                               //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if(monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);
                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        case 4:
            _biu[i].setPosX(_biu[i].getPosX()+1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3)
            {
                                                //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if(monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);

                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        }
        if(_biu[i].getdistance()<_biu[i].gets())
        {
            vector<Bullet>::iterator qe;
            qe=_biu.begin()+i;
            _biu.erase(qe);
        }

    }
}

#include "monster.h"
#include <iostream>
#include <algorithm>
#include <cmath>
#include <QPainter>
#include <string>
#include <QPainter>
#include <QMediaPlayer>

#include <QPaintEvent>
using namespace std;



//direction =1,2,3,4 for 上下左右
void Monster::showinfo(QPainter *pa)
{


    pa->setPen(Qt::black); //添加画笔
    pa->drawRect(this->getPosX()*32-16, this->getPosY()*32-16, 64, 16); //绘制矩形
    pa->setBrush(Qt::red); //添加画刷
    pa->drawRect(this->getPosX()*32-16, this->getPosY()*32-16, 64*(blood/this->fullblood), 16); //绘制矩形
    pa->setBrush(Qt::NoBrush);

}

void Monster::move(int direction, int steps){
    switch (direction){
        case 1:

            this->_pos_y -= steps;
            if(_pos_y> 24||_pos_y<0)   _pos_y += steps;
            break;
        case 2:
            this->_pos_y += steps;
            if(_pos_y>24|_pos_y<0)   _pos_y -= steps;
            break;
        case 3:
            this->_pos_x -= steps;
            if(_pos_x>39||_pos_x<0)   _pos_x += steps;
            break;
        case 4:
            this->_pos_x += steps;
            if(_pos_x>39||_pos_x<0)   _pos_x -= steps;
            break;
    }
}

void Monster::setary0(int Q[30][30])
{
    Q[this->getPosX()][this->getPosY()+1]=0;
}

void Monster::setary3(int Q[30][30])
{
    Q[this->getPosX()][this->getPosY()+1]=3;
}

void Monster::onErase(){
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("C:\\Users\\win\\Desktop\\debugmap0609\\sf\\monss.wav"));
    player->setVolume(80);
    player->play();

}

#include "QApplication"
#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <QTimer>
#include <map>
#include <iostream>
#include <QPixmap>
#include <QPaintEvent>
#include <vector>
#include <QWidget>
#include<QLabel>
#include <fstream>
#include <QMessageBox>

using namespace std;
extern fstream file;



MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    this->setMinimumSize(1280,800);
    this->setMaximumSize(1280,800);
    //this->setWindowFlags(QT::FramelessWindowHint);
    state=0;        //初始化地图1
    ui->setupUi(this);
    _game.InitWorld("C:\\Users\\win\\Desktop\\migong.txt");//TODO 应该是输入有效的地图文件
    //game1.initWorld(":/map2.txt");
    //以下是对时钟的初始化
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(randomMove()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
    timer->start(1000);
    timer->setInterval(600);

    time1 = new QTimer(this);
    connect(time1,SIGNAL(timeout()),this,SLOT(drugrand()));//timeoutslot()为自定义槽
        //时钟事件与drugrand函数绑定
    time1->start(1000);
    time1->setInterval(10000);

    time2 = new QTimer(this);
    connect(time2,SIGNAL(timeout()),this,SLOT(bulletmove()));//timeoutslot()为自定义槽
        //时钟事件与bulletmove函数绑定
    time2->start(1000);
    time2->setInterval(50);

    time3 = new QTimer(this);
    connect(time3,SIGNAL(timeout()),this,SLOT(monsrand()));//timeoutslot()为自定义槽
        //时钟事件与monsrand()函数绑定
    time3->start(1000);
    time3->setInterval(100000000000000);

    time4 = new QTimer(this);
    connect(time4,SIGNAL(timeout()),this,SLOT(volmove()));//将时钟和伏地魔的移动函数volmove()绑定在一起
    time4->start(1000);
    time4->setInterval(50);//此处根据游戏难度设置时间间隔，将总时间控制为游戏总限制时间

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        //设置随机数种子


}

MW1::~MW1()
{
    delete ui;
}
void MW1::setState(int st){
    state=st;      //设置
}

void MW1::paintEvent(QPaintEvent *e){

    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    if (_game._player.blood<=0&&state!=0)
    {
        state=4;                            //玩家死亡
    }
    if(state==0){
        QPixmap image9;
        image9.load(":/:/111.jpg");
        pa->drawPixmap(0,0,1280,800,image9);
        this->_game.show(pa);
        QPixmap image2;
        image2.load(":/:/juanzhouy.png");
        pa->drawPixmap(0,0,192,64,image2);
        QFont font("宋体", 10, QFont::Bold, false);
        //设置下划线
        font.setUnderline(true);
        //设置上划线
        font.setOverline(true);
        //设置字母大小写
        font.setCapitalization(QFont::SmallCaps);
        //设置字符间的间距
        font.setLetterSpacing(QFont::AbsoluteSpacing, 2);
        //使用字体
        pa->setFont(font);
        pa->setPen(Qt::black);
        pa->drawText(16, 16, tr("RED "));
        pa->drawText(16, 36, tr("BLU"));
        pa->drawText(16, 56, tr("YEL"));
          pa->setPen(Qt::black); //添加画笔
          pa->drawRect(40,5,130,16); //绘制矩形
          pa->drawRect(40,25,130,16);
          pa->drawRect(40,45,130,16);
          pa->setBrush(Qt::red); //添加画刷
          pa->drawRect(40, 5, 130*(_game._player.red/_game._player.fullr), 16); //绘制矩形
          pa->setBrush(Qt::blue); //添加画刷
          pa->drawRect(40,25,130*(_game._player.blue/_game._player.fullb),16);
          pa->setBrush(Qt::yellow); //添加画刷
          pa->drawRect(40,45,130*(_game._player.yellow/_game._player.fully),16);

    }
    else if(state==1)
    {
        QPixmap image1;
        image1.load(":/map1.jpg");
        pa->drawPixmap(0,0,1280,800,image1);
        this->_game.show(pa);
    }
    else if (state==2&&_game.monsters.size()!=0)
    {
        QPixmap image3;
        image3.load(":/map2.jpg");
        pa->drawPixmap(0,0,1280,800,image3);
        this->_game.show(pa);
    }
    else if (state==2&&_game.monsters.size()==0)
    {
        state=3;
        _game._objs.clear();_game._biu.clear();_game._player._exsistence=false;
    }
    else if(state==3)
    {
        QPixmap image4;
        image4.load(":/win.png");
        pa->drawPixmap(0,0,1280,800,image4);
        this->_game.show(pa);
    }
    else if(state==4)
    {
        _game._objs.clear();_game._biu.clear();_game.monsters.clear();
        QPixmap image5;
        image5.load(":/lose.png");
        pa->drawPixmap(0,0,1280,800,image5);
        this->_game.show(pa);
    }

    if(state==1||state==2){
        QPixmap image2;
        image2.load(":/:/juanzhouy.png");
        pa->drawPixmap(0,0,192,64,image2);
       // this->_game.show(pa);

        QFont font("宋体", 10, QFont::Bold, false);
        //设置下划线
        font.setUnderline(true);
        //设置上划线
        font.setOverline(true);
        //设置字母大小写
        font.setCapitalization(QFont::SmallCaps);
        //设置字符间的间距
        font.setLetterSpacing(QFont::AbsoluteSpacing, 2);
        //使用字体
        pa->setFont(font);
        pa->setPen(Qt::black);
        pa->drawText(16, 16, tr("HP"));
        pa->drawText(16, 36, tr("MP"));
        pa->drawText(16, 56, tr("XP"));
        //pa->translate(50, 50);
       // pa->rotate(90);
        //pa->drawText(0, 0, tr("helloqt"));

          pa->setPen(Qt::black); //添加画笔
          pa->drawRect(40, 5, 130, 16); //绘制矩形
          pa->drawRect(40,25,130,16);
          pa->drawRect(40,45,130,16);
          pa->setBrush(Qt::red); //添加画刷
          if(_game._player.blood>0)
          pa->drawRect(40, 5, 130*(_game._player.blood/_game._player.fullblood), 16); //绘制矩形
          pa->setBrush(Qt::blue); //添加画刷
          pa->drawRect(40,25,130*(_game._player.power/_game._player.fullpower),16);
          pa->setBrush(Qt::yellow); //添加画刷
          pa->drawRect(40,45,130*(_game._player.exp/_game._player.fullexp),16);

    }
    pa->end();
    delete pa;
    order1=0;order2=0;order3=0;order4=0;

}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //cout<<_game.ary[2][4]<<endl;
    //cout<<state<<" "<<this->_game._player.getPosX()<<" "<<this->_game._player.getPosY()<<endl;
    //改变人的state
    if(this->_game._player.getPosX()==39&&this->_game._player.getPosY()==6||this->_game._player.getPosX()==38&&this->_game._player.getPosY()==6
            ||this->_game._player.getPosX()==39&&this->_game._player.getPosY()==7||this->_game._player.getPosX()==38&&this->_game._player.getPosY()==7)         //进入下一层
    {
        if(state==1){
            state=2;        //进入下个界面
            QMessageBox::StandardButton btnValue = QMessageBox::information(this, "Dialog","big boss is here!   plz be careful!!!");
            if (btnValue == QMessageBox::Ok)
            _game.initWorld("C:\\Users\\win\\Desktop\\Map (2).txt");        //第二个图的文件
        }
    }
    else if(this->_game._player.getPosX()==30&&this->_game._player.getPosY()==23&&state==0){
        state=1;
        //QMessageBox::StandardButton btnValue = QMessageBox::information(this, "Dialog","welcome to the black forest!");
        //if (btnValue == QMessageBox::Ok)    cout<<"1"<<endl;
        _game.initWorld("C:\\Users\\win\\Desktop\\map.txt");
    }
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A&&state!=0)
    {
        this->_game._player._pic=this->_game._player.Dir[2][order1].copy(0,0,32,64);
        order1++;
        if(order1==4)   order1=0;
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D&&state!=0)
    {
        this->_game._player._pic=this->_game._player.Dir[3][order2].copy(0,0,32,64);
        order2++;
        if(order2==4)   order2=0;
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W&&state!=0)
    {
        this->_game._player._pic=this->_game._player.Dir[0][order3].copy(0,0,32,64);
        order3++;
        if(order3==4)   order3=0;
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S&&state!=0)
    {
        this->_game._player._pic=this->_game._player.Dir[1][order4].copy(0,0,32,64);
        order4++;
        if(order4==4)   order4=0;
        this->_game.handlePlayerMove(2,1);
    }
    else if(e->key() == Qt::Key_A&&state==0)
    {
        this->_game._player._pic=this->_game._player.Dir[2][order1].copy(0,0,32,64);
        order1++;
        if(order1==4)   order1=0;
        this->_game.HandlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D&&state==0)
    {
        this->_game._player._pic=this->_game._player.Dir[3][order2].copy(0,0,32,64);
        order2++;
        if(order2==4)   order2=0;
        this->_game.HandlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W&&state==0)
    {
        this->_game._player._pic=this->_game._player.Dir[0][order3].copy(0,0,32,64);
        order3++;
        if(order3==4)   order3=0;
        this->_game.HandlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S&&state==0)
    {
        this->_game._player._pic=this->_game._player.Dir[1][order4].copy(0,0,32,64);
        order4++;
        if(order4==4)   order4=0;
        this->_game.HandlePlayerMove(2,1);
    }
    else if(e->key() == Qt::Key_J&&_game._player.blood>0)
    {
        this->_game.playerattack();
    }
    else if(e->key() == Qt::Key_K&&_game._player.power>0&&_game._player.blood>0)
    {
       if(_game._player.power>0)
            this->_game.playerskill();
       if(_game._player.power>=10)
            _game._player.power=_game._player.power-10;                             //放技能能量减10
    }
    else if(e->key() == Qt::Key_R)                  //P读档
    {
        state=1;
        _game.initWorld("C:\\Users\\win\\Desktop\\map.txt");
    }
    //////读档
    else if(e->key() == Qt::Key_P)                  //P读档
    {
        _game.ary[_game._player.getPosX()][_game._player.getPosY()+1]=0;
        int a;
        file.open("C:\\Users\\win\\Desktop\\now_map.txt",ios::in);
        file>>a;
        setState(a);
        file.close();
        _game.initWorld("C:\\Users\\win\\Desktop\\now_map.txt");
    }
    this->repaint();
}


void MW1::randomMove(){
    int d = 1 + rand()%4;
    this->_game.handlevold(d,1);
    this->repaint();
}

void MW1::drugrand(){
    int x =rand()%24;    int y=rand()%16+1;
    if(state==1)    this->_game.Drugrand(x,y);
    else if(state==2)   this->_game.Drugrand(x,y);
    this->repaint();
}

void MW1::monsrand(){
    int x =rand()%24;    int y=rand()%20+1;
    this->_game.snakemove(x,y);
    this->repaint();
}

void MW1::bulletmove()
{
    int x=rand()%2;
    if(state==1)    this->_game.bulletfly();
    else if(state==2)   this->_game.bulletfly();
    this->repaint();
}


void MW1::volmove(int _order){
    this->_game.handlevold(vol.vo_route[_order],1);
    this->repaint();
    order++;
}

void MW1::save()
{    fstream infile;
     infile.open("C:\\Users\\win\\Desktop\\now_map.txt",ios::out|ios::trunc);
      if(infile.is_open())
      {   vector<Bullet>::iterator bullet;
          vector<Monster>::iterator mon;
          vector<RPGObj>::iterator obj;
          infile<<state<<endl;
          infile<<"player "<<_game._player.getPosX()<<" "<<_game._player.getPosY()<<" "<<_game._player.blood
               <<" "         <<_game._player.power<<" "<<_game._player.exp<<" "<<_game._player.rank<<" "<<_game._player.fullblood<<" "<<_game._player.fullpower<<endl;
          for(bullet=_game._biu.begin();bullet<_game._biu.end();bullet++)
          {        infile<<"bullet ";
              int a=(*bullet).getPosX();
              infile<<a<<" ";
              int b=(*bullet).getPosY();
              infile<<b<<" ";
              int c=(*bullet).gets();
              infile<<c<<" ";
              int d=(*bullet).getstate();
              infile<<d<<endl;
          }
          infile<<"MONSTER"<<endl;
          for(mon=_game.monsters.begin();mon<_game.monsters.end();mon++)
          {
              if((*mon).getObjType().find("onstery")!= (*mon).getObjType().npos) infile<<"monstery"<<" "<<(*mon).getPosX()<<" "<<(*mon).getPosY()<<" "<<(*mon).blood<<endl;
             else infile<<(*mon).getObjType()<<" "<<(*mon).getPosX()<<" "<<(*mon).getPosY()<<" "<<(*mon).blood<<endl;
          }
          infile<<"RPGOBJ"<<endl;
          for(obj=_game._objs.begin();obj<_game._objs.end();obj++)
          {

                infile<<(*obj).getObjType()<<" "<<(*obj).getPosX()<<" "<<(*obj).getPosY()<<endl;
          }
          infile<<"EOF"<<endl;
          infile.close();
      }
}
/*QFont font("宋体", 15, QFont::Bold, true);
//设置下划线
font.setUnderline(true);
//设置上划线
font.setOverline(true);
//设置字母大小写
font.setCapitalization(QFont::SmallCaps);
//设置字符间的间距
font.setLetterSpacing(QFont::AbsoluteSpacing, 10);
//使用字体
painter.setFont(font);
painter.setPen(Qt::blue);
painter.drawText(120, 80, tr("yafeilinux"));
painter.translate(50, 50);
painter.rotate(90);
painter.drawText(0, 0, tr("helloqt"));*/

void MW1::on_pushButton_clicked()
{
    save();
}

#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QSound>
#include <QMainWindow>
#include "GameModel.h"


#define CHESS_ONE_SOUND ":/res/sound/chessone.wav"
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    // 绘制
    void paintEvent(QPaintEvent *event);
    // 接收鼠标移动情况，方便落子
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);//落子

private:
    GameModel *game; // 游戏指针
    int clickPosRow, clickPosCol; // 存储将点击的位置
    void initGame();
    void checkGame(int y,int x);

private slots:
    void chessOneByPerson();
    void chessOneByAI();

    void initPVEGame();
};

#endif // MAINWINDOW_H

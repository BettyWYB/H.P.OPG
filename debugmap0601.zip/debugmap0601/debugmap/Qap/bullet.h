#ifndef BULLET_H
#define BULLET_H
#include "rpgobj.h"


class Bullet:public RPGObj
{
public:
    Bullet(){}
    void inibullet(int x,int y,int now_s,int State){inix=x;iniy=y;distance=8;s=now_s;state=State;}       //初始化子弹

    void sets(int S){this->s=S;}
    int gets(){return this->s;}

    void setinix(int x){inix=x;}
    int getinix(){return inix;}

    void setiniy(int y){iniy=y;}
    int getiniy(){return iniy;}

    void setstate(int x){state=x;}
    int getstate(){return state;}

    int getdistance(){return distance;}
protected:
    int inix,iniy;          //初始坐标
    int s;                  //
    int distance;           //攻击距离
    int state;              //攻击的类型             //1是普通攻击  2是skill
};

#endif // BULLET_H

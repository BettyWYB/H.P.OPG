#ifndef PLAYER_H
#define PLAYER_H
#include <QImage>
#include <QPainter>
#include "rpgobj.h"



class Player:public RPGObj
{
public:
    Player(){}
    ~Player(){}
    //Player(const Player &s);
    void iniplayer();
    void move(int direction, int steps=1);
        //direction =1,2,3,4 for 上下左右
    void setary0(int Q[50][40]);
    void setary3(int Q[50][40]);
    void showinfo(QPainter * pa);
    void rankUP();
    void onErase();
    void hurt();

protected:



};

#endif // PLAYER_H

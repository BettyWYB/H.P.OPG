#ifndef GAMEMODEL_H
#define GAMEMODEL_H

#include <vector>
using std::vector;

// 游戏状态
enum GameStatus
{
    PLAYING,
    WIN,
    DEAD
};

//pc执黑子先手

// 棋盘尺寸
const int kBoardSizeNum = 5;

class GameModel
{
public:
    GameModel();

public:
    int gamemap[9][9];    //存储当前游戏棋盘和棋子的情况,空白为0，白子1，黑子-1   5*5的棋盘扩宽为9*9用于判断边界
    int score[9][9];  //储存各个点的分数
    bool playerFlag; // 标识下棋方
    GameStatus gameStatus; // 游戏状态

    void startGame(); // 初始化游戏
    void inimap();    //初始化地图
    void iniscore();  //初始化分数
    void calculateScore(); // 计算评分
    void actionByPerson(int x,int y); // 人执行下棋
    void actionByAI(); // 机器执行下棋
    void updateGameMap(int x,int y); // 每次落子后更新游戏棋盘
    bool isWin(int x,int y); // 判断游戏是否胜利
    bool isDeadGame(); // 判断是否和棋
    void updatevitual();
};

#endif // GAMEMODEL_H

#include "icon.h"
#include<iostream>
int ICON::GRID_SIZE = 32;


pair<string,ICON> pairArray[] =
{
    make_pair("player",ICON("player",0,0, 1, 2)),
    make_pair("monstery",ICON("monstery",1,13, 1, 2)),
    make_pair("stone",ICON("stone",4,9, 1, 1)),
    make_pair("fruit",ICON("fruit",3,6, 1, 1)),
    make_pair("red",ICON("red",0,0,1,1)),
    make_pair("blue",ICON("blue",0,0,1,1)),
    make_pair("tree1",ICON("tree1",0,0, 2, 2)),
    make_pair("well",ICON("well",0,11,2,2)),
    make_pair("door",ICON("door",0,0,2,2)),
    make_pair("vat",ICON("vat",0,0,1,1)),
    make_pair("biu",ICON("biu",0,0,1,1)),
    make_pair("snow",ICON("snow",0,0,2,2)),
    make_pair("monsterx",ICON("monsterx",0,0,1,2)),
    make_pair("Biu",ICON("Biu",0,0,0.75,0.75)),              //技能
    make_pair("stonen",ICON("stonen",5,0, 1, 1)),
    make_pair("fruitn",ICON("fruitn",3,6, 1, 1)),
    make_pair("redn",ICON("redn",0,0,1,1)),
    make_pair("bluen",ICON("bluen",0,0,1,1)),
    make_pair("yellow",ICON("yellow",0,0,1,1)),
    make_pair("rdoor",ICON("rdoor",2,0,1,1)),
    make_pair("bdoor",ICON("bdoor",1,0,1,1)),
    make_pair("ydoor",ICON("ydoor",0,0,1,1))
};

map<string,ICON> ICON::GAME_ICON_SET(pairArray,pairArray+sizeof(pairArray)/sizeof(pairArray[0]));


ICON::ICON(string name, int x, int y, int w, int h){
    this->typeName = name;
    this->srcX = x;
    this->srcY = y;
    this->width = w;
    this->height = h;
}

ICON ICON::findICON(string type){
    map<string,ICON>::iterator kv;
    kv = ICON::GAME_ICON_SET.find(type);
    if (kv==ICON::GAME_ICON_SET.end()){

       cout<<"Error: cannot find ICON"<<endl;
       return ICON();
    }
    else{
        return kv->second;
    }

}

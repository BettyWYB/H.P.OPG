#include "dementor.h"

//Dementor::Dementor()
//{

//}

#include "mw1.h"
#include "mw2.h"
#include "world.h"
#include "logindlg.h"
#include <QApplication>
#include <fstream>
using namespace std;
fstream file;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //MainWindow w;
    //w.show();
    MW1 mw1;
    LoginDlg dlg;                        // 建立自己新建的类的对象dlg
    if(dlg.exec() == QDialog::Accepted) // 利用Accepted返回值判断按钮是否被按下
    {
        int st;
        file.open("C:\\Users\\123213\\Desktop\\map.txt",ios::in);
        file>>st;   //首先获取文件中第一行的当前世界所需画面
        cout<<st<<endl;
        mw1.setState(st);
       file.close();

       mw1.show();                      // 如果被按下，显示主窗口
       /////////////////////////////////////////////////////////////////
       //mw1.save();
       ////////////////////////////////////////////////////////////////////
       return a.exec();               // 程序一直执行，直到主窗口关闭
   }
       else return 0;            //如果没被按下，则不会进入主窗口，整个程序结束运行


    //return a.exec();
}

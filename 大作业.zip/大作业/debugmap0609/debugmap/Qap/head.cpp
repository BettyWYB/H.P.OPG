#include "head.h"

extern int ary[30][30];


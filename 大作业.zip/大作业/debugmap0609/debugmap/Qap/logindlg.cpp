#include "logindlg.h"
#include "ui_logindlg.h"
#include<QImage>
#include <QPainter>
#include <string>
#include<QPixmap>

LoginDlg::LoginDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDlg)
{
    ui->setupUi(this);
}

LoginDlg::~LoginDlg()
{
    delete ui;
}

void LoginDlg::show(QPainter *painter)
{



}

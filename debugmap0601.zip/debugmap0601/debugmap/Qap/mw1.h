#ifndef MW1_H
#define MW1_H
#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include "rpgobj.h"
#include "world.h"
#include<QTime>
#include<QTimer>
#include "voldemort.h"
#include<fstream>
using namespace std;


namespace Ui {
class MW1;
}

class MW1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *);
    void save();//in order to save the current world
    void setState(int st);


protected slots:
    void randomMove();//响应时钟事件的函数
    void drugrand();
    void bulletmove();
    void monsrand();
    void volmove(int order);//伏地魔移动,order 表示对应文件中的第几步
private:
    Ui::MW1 *ui;
    World _game,game1,game2;
    Voldemort vol;
    QTimer *timer,*time1,*time2,*time3,*time4;
        //时钟，控制玩家移动频率
    int state;    //游戏进行的状态 地图1 地图2 地图3
    int order;  //记录伏地魔移动的步数
    int order1,order2,order3,order4; //人移动步数
};

#endif // MW1_H

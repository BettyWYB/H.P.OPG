#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QImage>
#include <QPainter>
#include "player.h"
#include "icon.h"
#include <map>
#include <fstream>
#include <iostream>
#include "monster.h"
#include "bullet.h"
#include "voldemort.h"

using namespace std;


class World
{
public:
    World(){for(int i=0;i<30;i++){
            for(int j=0;j<30;j++){
                ary[i][j]=0;}}}
    ~World(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
           well 0 11
         */
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
        //假定只有一个玩家
    void handlevold(int direction,int steps);
        //控制伏地魔的移动
    void demmove(int direction,int steps);
        //控制摄魂怪的移动 direction=3

    void playerskill();

    void Drugrand(int x,int y);
        //随机出现药品

    void snakemove(int x,int y); //随机移动的大蛇
    Player _player;
    Voldemort Tom; //伏地魔名叫Tom


    void playerattack();
    void bulletfly();
    void voldattack(int x,int y,int Dir);


    vector<RPGObj> _objs;
    vector<Bullet> _biu;
    vector<Monster> monsters;
//    vector<Monster> dementors;

    int ary[30][30];          //初始二维数组


private:

    Monster _monster;
};

#endif // WORLD_H

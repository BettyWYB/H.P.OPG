#include "world.h"
#include "player.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include "rpgobj.h"
#include "bullet.h"
#include "monster.h"
#include <QMediaPlayer>
#include <QSound>
#include <vector>

void World::InitWorld(string mapFile){
    state=0;
    for(int i=0;i<40;i++){
        for(int j=0;j<25;j++)
            ary[i][j]=0;
    }
    _objs.clear();
    extern fstream file;
    string input;
    int pos_x,pos_y;
    this->_player.initObj("player",":/:/player.png");
    this->_player.setPosX(0);  //录入横坐标
    this->_player.setPosY(14);  //录入纵坐标
    ary[_player.getPosX()][_player.getPosY()+1]=4;  //初始化二维数组为4
    this->_player.red=0;this->_player.fullb=100;
    this->_player.blue=0;this->_player.fullr=100;
    this->_player.yellow=0;this->_player.fully=100;

    RPGObj obj;
       file.open("C:\\Users\\win\\Desktop\\migong.txt");
       if(!file.is_open()) cout<<"cannot open! "<<endl;
       if(file.is_open()){
           cout<<"canopen"<<endl;
            file>>input;
        while(input!="EOF"){
            if(input=="fruitn"){
                obj.initObj("fruitn",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=0;//设置二位数组为可过 实际上是草
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="stonen"){
                obj.initObj("stonen",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="redn"){                      //三个颜色的钥匙
                obj.initObj("redn",":/red1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=2;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="bluen"){
                obj.initObj("bluen",":/blue1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=2;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="yellow"){
                obj.initObj("yellow",":/yellow1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=2;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="rdoor"){
                obj.initObj("rdoor",":/zy1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="bdoor"){
                obj.initObj("bdoor",":/zy1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="ydoor"){
                obj.initObj("ydoor",":/zy1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else cout<<"cannot file icon!"<<endl;

        }


    //}
    if(input=="EOF") file.close();

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("C:\\Users\\win\\Desktop\\debugmap0609\\sf\\hp.mp3"));
    player->setVolume(30);
    player->play();
        }
    //二维数组为0，说明什么也没有，为1不可过，为2可吃,3为怪物 遇见要掉血,4是玩家


}


void World::initWorld(string mapFile){
    state=1;
    //读入地图文件，地图文件样例：
    //1（这是第几幅画面的标识）
    //player 5（x坐标） 5（y坐标） 90（当前血量） 80（当前蓝量） 20（当前经验） 3（当前等级）
    //bullet 4（x坐标） 6（y坐标） 2(当前已经过的距离) 1（状态，大招或是小招）
    //monster 6（x坐标） 8（y坐标） 50（当前血量）
    //RPGOBJ  //标识符
    //flower 7（x坐标） 5（y坐标）
    //EOF(文件结束标识)
    for(int i=0;i<40;i++){
        for(int j=0;j<25;j++)
            ary[i][j]=0;
    }
    monsters.clear();
    _objs.clear();
    _biu.clear();
    for(int i=0;i<40;i++){
        for(int j=0;j<=5;j++){
            ary[i][j]=1;
        }
        }
    ary[7][3]=0; ary[8][3]=0; ary[9][3]=0;ary[7][4]=0; ary[8][4]=0; ary[9][4]=0;ary[7][5]=0; ary[8][5]=0; ary[9][5]=0;
    extern fstream file;
    string input;
    int pos_x,pos_y,blood,power,exp,rank,now_dis,state,fullblood,fullpower;
    file.open(mapFile.c_str(),ios::in);
    file>>input;             //滤过第一个state
   // cout<<input<<endl;
    file>>input;            //首先录入player信息

    this->_player.initObj("player",":/:/player.png");  //bug

    file>>pos_x>>pos_y;
    this->_player.setPosX(pos_x);  //录入横坐标
    this->_player.setPosY(pos_y);  //录入纵坐标
    ary[_player.getPosX()][_player.getPosY()+1]=4;  //初始化二维数组为4
    file>>blood>>power>>exp>>rank>>fullblood>>fullpower;  //录入血量，蓝量，经验，等级
//    cout<<blood<<endl;
    this->_player.blood=blood;
    cout<<this->_player.blood<<endl;
    this->_player.power=power;
    cout<<this->_player.power<<endl;
    this->_player.exp=exp;
    cout<<this->_player.exp<<endl;
    this->_player.rank=rank;
    cout<<this->_player.rank<<endl;
    this->_player.fullblood=fullblood;
    this->_player.fullpower=fullpower;
    file>>input;




    Bullet bullet;
    while(input=="bullet"){//如果检测到正在录入子弹信息   重复录入
        file>>pos_x>>pos_y>>now_dis>>state;
        if(state==1)
            bullet.initObj("biu",":/:/feibiao.png");
        else
            bullet.initObj("Biu",":/:/feibiao.png");
        //bullet.inibullet(pos_x,pos_y,now_dis,state);
        this->_biu.push_back(bullet);
        file>>input;
    }
    Monster monster;
    if(input=="MONSTER"){//判断标识符怪物
        file>>input;
        while(input!="EOF"){
            if(input=="monstery"){
            monster.initObj(input,":/:/TileB.png");
            file>>pos_x>>pos_y>>blood;
            monster.setPosX(pos_x);
            monster.setPosY(pos_y);
            monster.blood=blood;
            ary[pos_x][pos_y+1]=3;//初始化二维数组为3
            this->monsters.push_back(monster);
            file>>input;
            }
            else if(input=="monsterx")
            {
                monster.initObj(input,":/2.png");
                file>>pos_x>>pos_y>>blood;
                monster.setPosX(pos_x);
                monster.setPosY(pos_y);
                monster.blood=blood;
                ary[pos_x][pos_y+1]=3;//初始化二维数组为3
                this->monsters.push_back(monster);
                file>>input;
            }
            else if(input=="snow")
            {
                monster.initObj(input,":/snowm.png");
                file>>pos_x>>pos_y>>blood;
                monster.setPosX(pos_x);
                monster.setPosY(pos_y);
                monster.blood=blood;
                ary[pos_x+1][pos_y+1]=3;
                ary[pos_x][pos_y+1]=3;//初始化二维数组为3
                this->monsters.push_back(monster);
                file>>input;
            }
            else break;
        }
     }
    RPGObj obj;
    if(input=="RPGOBJ"){//判断标识符物品
        file>>input;
        while(input!="EOF"){
            if(input=="fruit"){
                obj.initObj("fruit",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=0;//设置二位数组为可过 实际上是草
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="red"){
                obj.initObj("red",":/:/red.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=2;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="vat"){
                obj.initObj("vat",":/vat.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="blue"){
                obj.initObj("blue",":/:/blue.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=2;//设置二位数组为可吃的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="stone"){
                obj.initObj("stone",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="well"){
                obj.initObj("well",":/:/TileB.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;
                ary[pos_x+1][pos_y]=1;
                ary[pos_x][pos_y+1]=1;
                ary[pos_x+1][pos_y+1]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="door"){
                obj.initObj("door",":/door.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=0;
                ary[pos_x+1][pos_y]=0;
                ary[pos_x][pos_y+1]=0;
                ary[pos_x+1][pos_y+1]=0;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
            else if(input=="tree1"){
                obj.initObj("tree1",":/:/tree1.png");
                file>>pos_x>>pos_y;
                obj.setPosX(pos_x);
                obj.setPosY(pos_y);
                ary[pos_x][pos_y]=1;
                ary[pos_x+1][pos_y+1]=1;
                ary[pos_x+1][pos_y]=1;
                ary[pos_x][pos_y+1]=1;//设置二位数组为不可过的
                _objs.push_back(obj);
                file>>input;
            }
        }
    }
    if(input=="EOF") file.close();

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("C:\\Users\\win\\Desktop\\debugmap0609\\sf\\hp.mp3"));
    player->setVolume(30);
    player->play();


    //二维数组为0，说明什么也没有，为1不可过，为2可吃,3为怪物 遇见要掉血,4是玩家


}
void World::show(QPainter * painter){
    if(state==0){
        cout<<this->_player.red<<endl;
        for(int i=0;i<_objs.size();i++)
        {
            if(_objs[i]._exsistence==false)
            {
                ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                vector<RPGObj>::iterator de;
                de=_objs.begin()+i;
                _objs.erase(de);
            }
            _objs[i].show(painter);
        }
    this->_player.show(painter);            //加入血量
    }
    else{
        for(int i=0;i<_objs.size();i++)
        {
            if(_objs[i]._exsistence==false)
            {
                ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                vector<RPGObj>::iterator de;
                de=_objs.begin()+i;
                _objs.erase(de);
            }
            _objs[i].show(painter);
        }

        for(int i=0;i<monsters.size();i++)                           //加入血量
        {

            if(monsters[i]._exsistence==false)
            {
                ary[monsters[i].getPosX()][monsters[i].getPosY()]=0;
                vector<Monster>::iterator se;
                se=monsters.begin()+i;
                monsters.erase(se);
            }
            monsters[i].showinfo(painter);
            monsters[i].show(painter);
        }

        for(int i=0;i<_biu.size();i++)
        {
            if(_biu[i]._exsistence==false)
            {
                ary[_biu[i].getPosX()][_biu[i].getPosY()]=0;
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            _biu[i].show(painter);
        }
        if(_player.blood>0)
        this->_player.show(painter);            //加入血量
    }
}

void World::handlePlayerMove(int direction, int steps){


    switch (direction){
        case 1:
            _player.setdir(1);
            if(ary[_player.getPosX()][_player.getPosY()]==1)
               this->_player.move(direction,steps-1) ;
            else if(ary[_player.getPosX()][_player.getPosY()]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY())
                    {
                        if(_objs[i].getObjType().compare("red")==0)
                        {
                            if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                             if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                        }
                        if(_objs[i].getObjType().compare("blue")==0)
                        {
                            if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                            if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
                        }
                        _objs[i]._exsistence=false;
                        _objs[i].eat();
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()]=4;
                this->_player.move(direction,steps);
            }
            else if(ary[_player.getPosX()][_player.getPosY()]==3){
                this->_player.move(direction,steps-1);
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 2:
        _player.setdir(2);
            //this->_pos_y += steps;
            if(ary[_player.getPosX()][_player.getPosY()+2]==1)
                this->_player.move(direction,steps-1);
            else if(ary[_player.getPosX()][_player.getPosY()+2]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY()+2)
                    {
                        if(_objs[i].getObjType().compare("red")==0)
                        {
                            if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                             if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                        }
                        if(_objs[i].getObjType().compare("blue")==0)
                        {
                            if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                            if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
                        }
                        _objs[i]._exsistence=false;
                        _objs[i].eat();
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()+2]=4;
                this->_player.move(direction,steps);
                }

            else if(ary[_player.getPosX()][_player.getPosY()+2]==3){
                this->_player.move(direction,steps-1);
                //掉血
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()+2]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 3:
        _player.setdir(3);
            //this->_pos_x -= steps;
            if(ary[_player.getPosX()-1][_player.getPosY()+1]==1)
                this->_player.move(direction,steps-1);
            else if(ary[_player.getPosX()-1][_player.getPosY()+1]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()-1&&_objs[i].getPosY()==_player.getPosY()+1)
                    {
                        if(_objs[i].getObjType().compare("red")==0)
                        {
                            if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                             if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                        }
                        if(_objs[i].getObjType().compare("blue")==0)
                        {
                            if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                            if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
                        }
                        _objs[i]._exsistence=false;
                        _objs[i].eat();
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()-1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }

            else if(ary[_player.getPosX()-1][_player.getPosY()+1]==3){
                this->_player.move(direction,steps-1);
                //掉血
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()-1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 4:
        _player.setdir(4);
            //this->_pos_x += steps;
        //遇见石头
            if(ary[_player.getPosX()+1][_player.getPosY()+1]==1)            //下个位置
                this->_player.move(direction,steps-1);
        //遇见吃的
            else if(ary[_player.getPosX()+1][_player.getPosY()+1]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()+1&&_objs[i].getPosY()==_player.getPosY()+1)
                    {
                        if(_objs[i].getObjType().compare("red")==0)
                        {
                            if(_player.blood<=_player.fullblood-10)   _player.blood=_player.blood+10;
                             if(_player.blood>_player.fullblood-10)    _player.blood=_player.fullblood;
                        }
                        if(_objs[i].getObjType().compare("blue")==0)
                        {
                            if(_player.power>_player.fullpower-10)    _player.power=_player.fullpower;
                            if(_player.power<=_player.fullpower-10)    _player.power=_player.power+10;
                        }
                        _objs[i]._exsistence=false;
                        _objs[i].eat();
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()+1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }
        //遇见怪物
            else if(ary[_player.getPosX()+1][_player.getPosY()+1]==3){
                this->_player.move(direction,steps-1);
                //掉血
                _player.blood=_player.blood-10;
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()+1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }
            break;
    }
}

void World::snakemove(int x,int y)
{
    if(ary[x][y+1]==0)
    {
        Monster obl;
        obl.initObj("monster",":/:/TileB.png");
        obl.setPosX(x);
        obl.setPosY(y);
        obl._exsistence=true;
        ary[x][y+1]=3;
        if(monsters.size()<10)
        this->monsters.push_back(obl);

    }

}

void World::voldattack(int x, int y,int Dir)
{
    Bullet ss;
    ss.initObj("biu",":/:/feibiao.png");
    ss.setdir(Dir);ss.setstate(3);
    switch(ss.getdir())
    {
    case 1:
        ss.setPosX(x);
        ss.setPosY(y);
        break;
    case 2:
        ss.setPosX(x);
        ss.setPosY(y+2);
        break;
    case 3:
        ss.setPosX(x-1);
        ss.setPosY(y+1);
        break;
    case 4:
        ss.setPosX(x+1);
        ss.setPosY(y+1);
        break;
    }
    //ss.inibullet(x,y,0,1);
    _biu.push_back(ss);
}

void World::handlevold(int direction,int steps){
    for(int i=0;i<monsters.size();i++)
    {
        /*       if(direction==3&&monsters[i].getObjType().compare("voldemort")==0)   //如果是摄魂怪
        {
            this->monsters[i]._pic=this->monsters[i].Dir[3][0].copy(0,0,32,64);
        }
        else if(direction==4&&monsters[i].getObjType().compare("voldemor")==0)   //如果是摄魂怪
        {
            this->monsters[i]._pic=this->monsters[i].Dir[4][0].copy(0,0,32,64);
        }*/
        if(_player.getPosX()<monsters[i].getPosX()&&_player.getPosY()<monsters[i].getPosY())
        {
            if(rand()%2==0) direction=1;
            else if(rand()%2==1) direction=3;
        }
        else if(_player.getPosX()>monsters[i].getPosX()&&_player.getPosY()<monsters[i].getPosY())
        {
            if(rand()%2==0) direction=1;
            else if(rand()%2==1) direction=4;
        }
        else if(_player.getPosX()<monsters[i].getPosX()&&_player.getPosY()>monsters[i].getPosY())
        {
            if(rand()%2==0) direction=2;
            else if(rand()%2==1) direction=3;
        }
        else if(_player.getPosX()>monsters[i].getPosX()&&_player.getPosY()>monsters[i].getPosY())
        {
            if(rand()%2==0) direction=2;
            else if(rand()%2==1) direction=4;
        }
        else if(_player.getPosX()>monsters[i].getPosX()&&_player.getPosY()==monsters[i].getPosY())   direction=4;
        else if(_player.getPosX()<monsters[i].getPosX()&&_player.getPosY()==monsters[i].getPosY())   direction=3;
        else if(_player.getPosX()==monsters[i].getPosX()&&_player.getPosY()<monsters[i].getPosY())   direction=1;
        else if(_player.getPosX()==monsters[i].getPosX()&&_player.getPosY()>monsters[i].getPosY())   direction=2;

        switch (direction){
            case 1:
                monsters[i].setdir(1);
                if(_player.getPosX()==monsters[i].getPosX()&&_player.getPosY()<monsters[i].getPosY())
                {
                    voldattack(monsters[i].getPosX(),monsters[i].getPosY(),1);
                }
                if(ary[monsters[i].getPosX()][monsters[i].getPosY()]==1||ary[monsters[i].getPosX()][monsters[i].getPosY()]==2||ary[monsters[i].getPosX()][monsters[i].getPosY()]==3||ary[monsters[i].getPosX()][monsters[i].getPosY()]==4)
                   this->monsters[i].move(1,steps-1) ;
                else
                {
                    if(this->monsters[i].getObjType().find("onstery")!= monsters[i].getObjType().npos)
                    {
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(1 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;}
                    else if(this->monsters[i].getObjType().compare("monsterx")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(1 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                    }
                    else if(this->monsters[i].getObjType().compare("snow")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(1 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=3;
                    }

                }
                break;
            case 2:
             monsters[i].setdir(2);
             if(_player.getPosX()==monsters[i].getPosX()&&_player.getPosY()>monsters[i].getPosY())
             {
                voldattack(monsters[i].getPosX(),monsters[i].getPosY(),2);
             }
                //this->_pos_y += steps;
                if(ary[monsters[i].getPosX()][monsters[i].getPosY()+2]==1||ary[monsters[i].getPosX()][monsters[i].getPosY()]==2||ary[monsters[i].getPosX()][monsters[i].getPosY()+2]==3||ary[monsters[i].getPosX()][monsters[i].getPosY()+2]==4)
                    this->monsters[i].move(2,steps-1);
                else
                    {
                    if(this->monsters[i].getObjType().find("onstery")!=monsters[i].getObjType().npos)
                    {
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(2 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;}
                    else if(this->monsters[i].getObjType().compare("monsterx")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(2 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                    }
                    else if(this->monsters[i].getObjType().compare("snow")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(2 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=3;
                    }

                    }
                break;
            case 3:
             monsters[i].setdir(3);
             if(_player.getPosX()<monsters[i].getPosX()&&_player.getPosY()==monsters[i].getPosY())
             {
                 voldattack(monsters[i].getPosX(),monsters[i].getPosY(),3);
             }
                //this->_pos_x -= steps;
                if(ary[monsters[i].getPosX()-1][monsters[i].getPosY()+1]==1||ary[monsters[i].getPosX()][monsters[i].getPosY()]==2||ary[monsters[i].getPosX()-1][monsters[i].getPosY()+1]==3||ary[monsters[i].getPosX()-1][monsters[i].getPosY()+1]==4)
                    this->monsters[i].move(3,steps-1);
                else
                {
                    if(this->monsters[i].getObjType().find("onstery")!= monsters[i].getObjType().npos)
                    {
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(3 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;}
                    else if(this->monsters[i].getObjType().compare("monsterx")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(3 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                    }
                    else if(this->monsters[i].getObjType().compare("snow")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(3 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=3;
                    }

                }
                break;
            case 4:
             monsters[i].setdir(4);
             if(_player.getPosX()>monsters[i].getPosX()&&_player.getPosY()==monsters[i].getPosY())
             {
                 voldattack(monsters[i].getPosX(),monsters[i].getPosY(),4);
             }
                //this->_pos_x += steps;
                if(ary[monsters[i].getPosX()+1][monsters[i].getPosY()+1]==1||ary[monsters[i].getPosX()][monsters[i].getPosY()]==2||ary[monsters[i].getPosX()+1][monsters[i].getPosY()+1]==3||ary[monsters[i].getPosX()+1][monsters[i].getPosY()+1]==4)
                    this->monsters[i].move(4,steps-1);
                else
                {
                    if(this->monsters[i].getObjType().find("onstery")!=monsters[i].getObjType().npos)
                    {
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(4 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;}
                    else if(this->monsters[i].getObjType().compare("monsterx")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(4 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                    }
                    else if(this->monsters[i].getObjType().compare("snow")==0){
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=0;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=0;
                        this->monsters[i].move(4 ,steps);
                        ary[this->monsters[i].getPosX()][this->monsters[i].getPosY()+1]=3;
                        ary[this->monsters[i].getPosX()+1][this->monsters[i].getPosY()+1]=3;
                    }

                }
                break;
        }
    }
}

void World::Drugrand(int x,int y)
{
    if(ary[x][y]==0)
    {
        RPGObj obk;
        if(x*y%2==0)    obk.initObj("red",":/:/red.png");
        if(x*y%2==1)    obk.initObj("blue",":/:/blue.png");
        obk.setPosX(x);
        obk.setPosY(y);
        obk._exsistence=true;
        ary[x][y]=2;
        this->_objs.push_back(obk);
    }


}

void World::playerattack()
{
    Bullet Biu;
    Biu.initObj("biu",":/:/biu.png");
    Biu.setdir(_player.getdir());
    switch(Biu.getdir())
    {
    case 1:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        break;
    case 2:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        break;
    case 3:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        break;
    case 4:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        break;
    }
    //Biu.inibullet(_player.getPosX(),_player.getPosY(),0,1);
    Biu.playsound();
    _biu.push_back(Biu);

}

void World::playerskill()
{
    Bullet Biu;
    Biu.initObj("Biu",":/:/feibiao.png");         //技能
    Biu.setdir(_player.getdir());
    switch(Biu.getdir())
    {
    case 1:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        //应用不同的图像
        Biu._pic=Biu.Dir[0][0].copy(0,0,32,32);             //上
        break;
    case 2:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        Biu._pic=Biu.Dir[1][0].copy(0,0,32,32);             //下
        break;
    case 3:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        Biu._pic=Biu.Dir[2][0].copy(0,0,32,32);             //左
        break;
    case 4:
        Biu.setPosX(_player.getPosX());
        Biu.setPosY(_player.getPosY()+1);
        Biu._pic=Biu.Dir[3][0].copy(0,0,32,32);             //右
        break;
    }
    //Biu.inibullet(_player.getPosX(),_player.getPosY(),0,2);
    Biu.playsound();
    _biu.push_back(Biu);

}
/////////////////////////////////////子弹遇见人消失  打怪物或人掉血
void World::bulletfly()
{
    for(int i=0;i<_biu.size();i++)
    {
        _biu[i].sets(_biu[i].gets()+1);
        switch(_biu[i].getdir())
        {
        case 1:
           _biu[i].setPosY(_biu[i].getPosY()-1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3&&_biu[i].getstate()!=3)
            {
                                               //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if((monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                            ||(monsters[j].getPosX()+1==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY()))
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            if(monsters[j].getObjType().find("onstery")!= monsters[i].getObjType().npos)         ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("monsterx")==0)    ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("snow")==0)
                            {
                                ary[monsters[j].getPosX()+1][monsters[j].getPosY()+1]=0;  ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            }
                           // monsters[j].Erase();
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);                   //怪物血为0 消失
                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==1)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                _player.hurt();
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    //TODO
                    //此处应添加game over图像等或者使用复活药水
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        case 2:
            _biu[i].setPosY(_biu[i].getPosY()+1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3&&_biu[i].getstate()!=3)
            {
                                                //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if((monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                            ||(monsters[j].getPosX()+1==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY()))
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            if(monsters[j].getObjType().find("onstery")!= monsters[i].getObjType().npos)         ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("monsterx")==0)    ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("snow")==0)
                            {
                                ary[monsters[j].getPosX()+1][monsters[j].getPosY()+1]=0;  ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            }
                            monsters[j].onErase();
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);
                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==1)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                _player.hurt();
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        case 3:
            _biu[i].setPosX(_biu[i].getPosX()-1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3&&_biu[i].getstate()!=3)
            {
                                               //子弹消失
                for(int j=0;j<monsters.size();j++)
                { if((monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                            ||(monsters[j].getPosX()+1==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY()))
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            if(monsters[j].getObjType().find("onstery")!= monsters[i].getObjType().npos)         ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("monsterx")==0)    ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("snow")==0)
                            {
                                ary[monsters[j].getPosX()+1][monsters[j].getPosY()+1]=0;  ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            }
                            monsters[j].onErase();
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);
                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==1)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                 _player.hurt();
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                    _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        case 4:
            _biu[i].setPosX(_biu[i].getPosX()+1);
            if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==3&&_biu[i].getstate()!=3)
            {
                                                //子弹消失
                for(int j=0;j<monsters.size();j++)
                {
                    if((monsters[j].getPosX()==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY())
                            ||(monsters[j].getPosX()+1==_biu[i].getPosX()&&monsters[j].getPosY()+1==_biu[i].getPosY()))
                    {
                        if(_biu[i].getstate()==1)
                            monsters[j].blood=monsters[j].blood-10;
                        else if(_biu[i].getstate()==2)
                            monsters[j].blood=monsters[j].blood-30;
                        if(monsters[j].blood<=0)
                        {
                            if(_player.exp<_player.fullexp)  _player.exp+=20;                                    //升级
                            if(_player.exp>=_player.fullexp)
                            {
                               _player.exp=0;
                               _player.rankUP();
                            }
                            if(monsters[j].getObjType().find("onstery")!= monsters[i].getObjType().npos)         ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("monsterx")==0)    ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            else if(monsters[j].getObjType().compare("snow")==0)
                            {
                                ary[monsters[j].getPosX()+1][monsters[j].getPosY()+1]=0;  ary[monsters[j].getPosX()][monsters[j].getPosY()+1]=0;
                            }
                            monsters[j].onErase();
                            vector<Monster>::iterator be;
                            be=monsters.begin()+j;
                            monsters.erase(be);

                        }
                    }
                }
                vector<Bullet>::iterator ae;
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==1)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
            }
            else if(ary[_biu[i].getPosX()][_biu[i].getPosY()]==4)
            {
                vector<Bullet>::iterator ae;            //子弹消失
                ae=_biu.begin()+i;
                _biu.erase(ae);
                _player.blood-=20;
                 _player.hurt();
                if(_player.blood<=0)
                {
                    _player._exsistence=false;
                     _player.onErase();
                    ary[_player.getPosX()][_player.getPosY()+1]=0;
                }
            }
            break;
        }
        if(_biu[i].getdistance()<_biu[i].gets())
        {
            vector<Bullet>::iterator qe;
            qe=_biu.begin()+i;
            _biu.erase(qe);
        }

    }
}

void World::HandlePlayerMove(int direction, int steps){



    switch (direction){
        case 1:
            _player.setdir(1);
            //cout<<"向上走"<<endl;
            if(ary[_player.getPosX()][_player.getPosY()]==1)
            {
                for(int i=0;i<_objs.size();i++)
                {
                   if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY())//要改 判别前方位置
                   {

                          if(_objs[i].getObjType()=="rdoor"){
                               if(_player.red>=10){
                                   _player.red=_player.red-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           else if(_objs[i].getObjType()=="bdoor"){
                               if(_player.blue>=10){
                                   _player.blue=_player.blue-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           else if(_objs[i].getObjType()=="ydoor"){
                               if(_player.yellow>0){
                                   _player.yellow=_player.yellow-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                    this->_player.move(direction,steps-1);
                               }
                           }

                           else {
                               this->_player.move(direction,steps-1);
                           }
                     }

                }
           }

            else if(ary[_player.getPosX()][_player.getPosY()]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY())
                    {
                        _objs[i]._exsistence=false;
                        _objs[i].getkey();
                        if(_objs[i].getObjType()=="redn")
                        {
                            if(_player.red<=_player.fullr-10) _player.red=_player.red+10;
                            if(_player.red>_player.fullr-10) _player.red=_player.fullr;
                        }
                        else if(_objs[i].getObjType()=="bluen")
                        {
                            if(_player.blue<=_player.fullb-10) _player.blue=_player.blue+10;
                            if(_player.blue>_player.fullb-10) _player.blue=_player.fullb;
                        }
                        else if(_objs[i].getObjType()=="yellow")
                        {
                            if(_player.yellow<=_player.fully-10) _player.yellow=_player.yellow+10;
                            if(_player.yellow>_player.fully-10) _player.yellow=_player.fully;
                        }
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
            }

            else
                {
                cout<<"nothing"<<endl;
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                    ary[_player.getPosX()][_player.getPosY()]=4;
                    this->_player.move(direction,steps);
                }


            break;
        case 2:
        _player.setdir(2);
            //this->_pos_y += steps;
            if(ary[_player.getPosX()][_player.getPosY()+2]==1)
            {
                for(int i=0;i<_objs.size();i++)
                {
                   if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY()+2)//要改 判别前方位置
                   {

                           if(_objs[i].getObjType()=="rdoor"){
                               if(_player.red>=10){
                                   _player.red=_player.red-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           if(_objs[i].getObjType()=="bdoor"){
                               if(_player.blue>=10){
                                   _player.blue=_player.blue-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           if(_objs[i].getObjType()=="ydoor"){
                               if(_player.yellow>=10){
                                   _player.yellow=_player.yellow-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                    this->_player.move(direction,steps-1);
                               }
                           }
                           else this->_player.move(direction,steps-1);

                       }
                   }
                }


            else if(ary[_player.getPosX()][_player.getPosY()+2]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()&&_objs[i].getPosY()==_player.getPosY()+2)
                    {
                        _objs[i]._exsistence=false;
                        _objs[i].getkey();
                        if(_objs[i].getObjType()=="redn")
                        {
                            if(_player.red<=_player.fullr-10) _player.red=_player.red+10;
                            if(_player.red>_player.fullr-10) _player.red=_player.fullr;
                        }
                        else if(_objs[i].getObjType()=="bluen")
                        {
                            if(_player.blue<=_player.fullb-10) _player.blue=_player.blue+10;
                            if(_player.blue>_player.fullb-10) _player.blue=_player.fullb;
                        }
                        else if(_objs[i].getObjType()=="yellow")
                        {
                            if(_player.yellow<=_player.fully-10) _player.yellow=_player.yellow+10;
                            if(_player.yellow>_player.fully-10) _player.yellow=_player.fully;
                        }
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()+2]=4;
                this->_player.move(direction,steps);

            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()][_player.getPosY()+2]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 3:
        _player.setdir(3);
            //this->_pos_x -= steps;
            if(ary[_player.getPosX()-1][_player.getPosY()+1]==1)
            {
                for(int i=0;i<_objs.size();i++)
                {
                   if(_objs[i].getPosX()==_player.getPosX()-1&&_objs[i].getPosY()==_player.getPosY()+1)
                   {

                           if(_objs[i].getObjType()=="rdoor"){
                               if(_player.red>=10){
                                   _player.red=_player.red-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           if(_objs[i].getObjType()=="bdoor"){
                               if(_player.blue>=10){
                                   _player.blue=_player.blue-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           if(_objs[i].getObjType()=="ydoor"){
                               if(_player.yellow>=10){
                                   _player.yellow=_player.yellow-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                    this->_player.move(direction,steps-1);
                               }
                           }
                           else this->_player.move(direction,steps-1);
                       }
                   }

            }
            else if(ary[_player.getPosX()-1][_player.getPosY()+1]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if((_objs[i].getPosX()==(_player.getPosX()-1))&&(_objs[i].getPosY()==(_player.getPosY()+1)))
                    {
                        _objs[i]._exsistence=false;
                        _objs[i].getkey();
                        cout<<"red 3   "<<endl;
                        if(_objs[i].getObjType()=="redn")
                        {
                            if(_player.red<=_player.fullr-10) _player.red=_player.red+10;
                            cout<<"red "<<_player.red<<endl;
                            if(_player.red>_player.fullr-10) _player.red=_player.fullr;
                        }
                        else if(_objs[i].getObjType()=="bluen")
                        {
                            if(_player.blue<=_player.fullb-10) _player.blue=_player.blue+10;
                            cout<<"red "<<_player.blue<<endl;
                            if(_player.blue>_player.fullb-10) _player.blue=_player.fullb;
                        }
                        else if(_objs[i].getObjType()=="yellow")
                        {
                            if(_player.yellow<=_player.fully-10) _player.yellow=_player.yellow+10;
                            if(_player.yellow>_player.fully-10) _player.yellow=_player.fully;
                        }
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()-1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
            }

             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()-1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }

            break;
        case 4:
        _player.setdir(4);
            if(ary[_player.getPosX()+1][_player.getPosY()+1]==1)   {         //下个位置
                for(int i=0;i<_objs.size();i++)
                {
                   if(_objs[i].getPosX()==_player.getPosX()+1&&_objs[i].getPosY()==_player.getPosY()+1)//要改 判别前方位置
                   {

                           if(_objs[i].getObjType()=="rdoor"){
                               if(_player.red>=10){
                                   _player.red=_player.red-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           if(_objs[i].getObjType()=="bdoor"){
                               if(_player.blue>=0){
                                   _player.blue=_player.blue-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                   this->_player.move(direction,steps-1);
                               }
                           }
                           if(_objs[i].getObjType()=="ydoor"){
                               if(_player.yellow>=10){
                                   _player.yellow=_player.yellow-10;
                                   _objs[i].open();
                                   this->_player.move(direction,steps);
                                   _objs[i]._pic=_objs[i].Dir[0][1].copy(0,0,32,32);
                               }
                               else{
                                    this->_player.move(direction,steps-1);
                               }
                           }
                           else this->_player.move(direction,steps-1);
                       }

                }
            }
        //遇见吃的
            else if(ary[_player.getPosX()+1][_player.getPosY()+1]==2)
            {   for(int i=0;i<_objs.size();i++)
                {
                    if(_objs[i].getPosX()==_player.getPosX()+1&&_objs[i].getPosY()==_player.getPosY()+1)
                    {
                        _objs[i]._exsistence=false;
                        _objs[i].getkey();
                        if(_objs[i].getObjType()=="redn")
                        {
                            if(_player.red<=_player.fullr-10) _player.red=_player.red+10;
                            cout<<"red "<<_player.red<<endl;
                            if(_player.red>_player.fullr-10) _player.red=_player.fullr;
                        }
                        else if(_objs[i].getObjType()=="bluen")
                        {
                            if(_player.blue<=_player.fullb-10) _player.blue=_player.blue+10;
                            if(_player.blue>_player.fullb-10) _player.blue=_player.fullb;
                        }
                        else if(_objs[i].getObjType()=="yellow")
                        {
                            if(_player.yellow<=_player.fully-10) _player.yellow=_player.yellow+10;
                            if(_player.yellow>_player.fully-10) _player.yellow=_player.fully;
                        }
                        ary[_objs[i].getPosX()][_objs[i].getPosY()]=0;
                    }
                }
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()+1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
            }
             else
                {
                ary[_player.getPosX()][_player.getPosY()+1]=0;
                ary[_player.getPosX()+1][_player.getPosY()+1]=4;
                this->_player.move(direction,steps);
                }
            break;
    }

}

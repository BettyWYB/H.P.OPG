#include "position.h"



void position::setX(int a){
    x=a;
}
void position::setY(int a){
    y=a;
}
int position::getX(){
    return this->x;
}

int position::getY(){
    return this->y;
}

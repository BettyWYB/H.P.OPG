#ifndef LOGINDLG_H
#define LOGINDLG_H
#include<QImage>
#include <QPainter>
#include <string>
#include <QDialog>

namespace Ui {
class LoginDlg;
}

class LoginDlg : public QDialog
{
    Q_OBJECT

public:
    explicit LoginDlg(QWidget *parent = 0);
    ~LoginDlg();
    void show(QPainter * painter);

private:
    Ui::LoginDlg *ui;
    QImage pix;
};

#endif // LOGINDLG_H

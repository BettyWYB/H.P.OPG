#include "voldemort.h"
#include <fstream>
#include <iostream>
using namespace std;

int Voldemort::count=0;

void Voldemort::initroute(string fileName)
{
   fstream route;
   short position=1;

   route.open(fileName.c_str(),ios::in);
   for(int i=0;i<500;i++){
       if(route>>position){
           this->vo_route[i]=position;    //将文件中的方向逐步读入数组  文件样例：1 2 3 4 2 3
           count++;  //记录文件中一共有多少步数
       }
       else break;
   }
   route.close();
}


short Voldemort::getRoute(int a){//获取每一步的路线
    return vo_route[a];
}

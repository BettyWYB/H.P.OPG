#ifndef RPGOBJ_H
#define RPGOBJ_H
#include <QImage>
#include <QPainter>
#include <string>
#include <icon.h>
#include <map>
using namespace std;
class RPGObj
{
public:
    RPGObj(){}

    void initObj(string type,string route);
    void show(QPainter * painter);

    void setPosX(int x){this->_pos_x=x;}
    void setPosY(int y){this->_pos_y=y;}

    void setdir(int Dir){this->dir=Dir;}                //方向
    int getdir(){return this->dir;}

    void icloud(string route,int x,int y,int h,int l,int a,int b);

    int getPosX() const{return this->_pos_x;}
    int getPosY() const{return this->_pos_y;}
    int getHeight() const{return this->_icon.getHeight();}
    int getWidth() const{return this->_icon.getWidth();}

    bool canCover() {return this->_coverable;}
    bool canEat() {return this->_eatable;}
    bool exsistence() {return this->_exsistence;}
    bool _exsistence;
    string getObjType() const{return this->_icon.getTypeName();}//返回类名

    //对于人物而言
    double blood;double fullblood;
    double power;double fullpower;
    double exp;double fullexp;
    int rank;

    QImage _pic;
    QImage Dir[4][4];               //上下左右 0 1 2 3

protected:

protected:
    //所有坐标，单位均为游戏中的格
    QTimer *time4;
    int _pos_x, _pos_y;//该物体在游戏中当前位置（左上角坐标）
    ICON _icon;//可以从ICON中获取对象的素材，尺寸等信息
    bool _coverable;
    bool _eatable;
    int dir;            //1，2，3，4表示上下左右

};

#endif // RPGOBJ_H

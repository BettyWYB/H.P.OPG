#ifndef HEAD_H
#define HEAD_H


extern int ary[30][30];

#endif // HEAD_H

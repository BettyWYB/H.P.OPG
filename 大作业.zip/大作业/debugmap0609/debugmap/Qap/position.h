#ifndef POSITION_H
#define POSITION_H


class position
{
public:
    position(){x=0;y=0;}
    ~position(){}
    void setX(int a);
    void setY(int a);
    int getX();
    int getY();
private:
    int x;   //x坐标
    int y;   //y坐标
};

#endif // POSITION_H

#ifndef VOLDEMORT_H
#define VOLDEMORT_H
#include "monster.h"
#include <fstream>
class Voldemort: public Monster
{
public:
    Voldemort(){}
    //void conversation
    void initroute(string fileName);//读取文件中的伏地魔活动路径
    short getRoute(int a);//获取每一步的路线  TODO:需要让伏地魔按照文件中的路线行走，其中不受任何事物的影响（它只起显示时间的作用）
friend class MW1;

private:
    short vo_route[500];//存放每一步方向的数组，从文件中读取
    static int count;//文件中含有的步数
};

#endif // VOLDEMORT_H

#ifndef MONSTER_H
#define MONSTER_H
#include <QImage>
#include <QPainter>
#include "rpgobj.h"
#include"player.h"

class Monster:public Player
{
public:
    Monster(){}
    ~Monster(){}
    void inimonster();
    void move(int direction, int steps=1);
        //direction =1,2,3,4 for 上下左右
    void setary0(int Q[30][30]);
    void setary3(int Q[30][30]);
    void showinfo(QPainter * pa);
    void onErase();
protected:



};
#endif // MONSTER_H

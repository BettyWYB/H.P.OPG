#ifndef DEMENTOR_H
#define DEMENTOR_H
#include "monster.h"

class Dementor:public Monster
{
public:
    Dementor(){}
    ~Dementor(){}

};

#endif // DEMENTOR_H

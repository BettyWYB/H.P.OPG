#include "bullet.h"
#include "rpgobj.h"
#include <iostream>
void Bullet::initObj(string type,string route){
    distance=20;s=0;
    if(type.compare("biu")==0){
        this->_exsistence =true;
        state=1;
    }
    else if(type.compare("Biu")==0){
        this->_exsistence =true;
        state=2;
        this->icloud(":/:/skill4.png",0,0,1,2,0,0);
        this->icloud(":/:/skill1.png",0,0,1,2,1,0);
        this->icloud(":/:/skill2.png",0,0,2,1,2,0);         //初始化子弹
        this->icloud(":/:/skill3.png",0,0,2,1,3,0);
    }
    else{
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;
    const char * outt=route.c_str();
    all.load(outt);
    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

#include <QApplication>
#include "mainwindow.h"
#include <QTimer>
#include <QSound>
#include <QPainter>
#include <QMouseEvent>
#include <QMessageBox>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QDebug>
#include <math.h>
#include<iostream>
#include "mw1.h"
using namespace std;

#define CHESS_ONE_SOUND ":/chessone.wav"
#define WIN_SOUND ":/win.wav"
#define LOSE_SOUND ":/lose.wav "

const int kRadius = 15; // 棋子半径
const int kBlockSize = 40; // 格子的大小
const int kPosDelta = 20; // 鼠标点击的模糊距离上限


// -------------------- //

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    // 设置棋盘大小
    setFixedSize(kBlockSize * (kBoardSizeNum+1),kBlockSize * (kBoardSizeNum+1));
    setStyleSheet("background-color:yellow;");

    setMouseTracking(true);

    QAction *actionPVE = new QAction("Person VS Computer", this);
    connect(actionPVE, SIGNAL(triggered()), this, SLOT(initPVEGame()));

    // 开始游戏
    initGame();
}

MainWindow::~MainWindow()
{
    if (game)
    {
        delete game;
        //game = nullptr;
    }
}

void MainWindow::initGame()
{   
    // 初始化游戏模型
    game = new GameModel;
    initPVEGame();
}


void MainWindow::initPVEGame()
{
    game->gameStatus = PLAYING;
    game->startGame();
    chessOneByAI();
    update();
}

void MainWindow::paintEvent(QPaintEvent *event)
{

    QPainter painter(this);
    QPen pen;
    pen.setColor("black");
    pen.setWidth(2);// 调整线条宽度
    painter.setPen(pen);
    for (int i=0;i<6; i++)
    {
        painter.drawLine(kBlockSize * i, 0,kBlockSize * i, size().height());
        painter.drawLine(0,kBlockSize * i,size().width(),kBlockSize * i);
    }

    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    //cout<<this->clickPosCol<<" "<<this->clickPosRow<<endl;
    if( (clickPosRow>1&&clickPosRow<=7)&&(clickPosCol>1&&clickPosCol<=7)&&(game->gamemap[clickPosRow][clickPosCol]==0))
    {//(防止鼠标越界)

        if (game->playerFlag)
            brush.setColor(Qt::white);//设置白子颜色
        else
            brush.setColor(Qt::black);//设置黑子颜色
        painter.setBrush(brush);
        painter.drawRect(kBlockSize*clickPosCol,kBlockSize*clickPosRow,0,0);

    }
    /////
    //cout<<this->clickPosCol<<" "<<this->clickPosRow<<" "<<game->gamemap[(this->clickPosCol)+2][(this->clickPosRow)+2]<<endl;
    // 绘制棋子 
    for (int i=2;i<=7;i++)
        for (int j=2;j<=7;j++)
        {
            if (game->gamemap[i][j]==1)//绘制白棋
            {
                brush.setColor(Qt::white);
                painter.setBrush(brush);
                painter.drawEllipse(kBlockSize*(i-2)-kRadius,kBlockSize*(j-2)-kRadius,kRadius*2,kRadius*2);
            }
            else if (game->gamemap[i][j]==-1)//绘制黑棋
            {
                brush.setColor(Qt::black);
                painter.setBrush(brush);
                painter.drawEllipse(kBlockSize*(i-2)-kRadius,kBlockSize*(j-2)-kRadius,kRadius*2,kRadius*2);
            }
        }

    // 判断输赢
    if (clickPosRow >= 2 && clickPosRow <= 7&&
        clickPosCol >= 2 && clickPosCol <= 7&&
        ((game->gamemap[clickPosRow][clickPosCol] == 1)||(game->gamemap[clickPosRow][clickPosCol] == -1)))
    {
        if (game->isWin(clickPosRow, clickPosCol)&&game->gameStatus == PLAYING)//检测到已经胜利
        {
            game->gameStatus = WIN;

            QString str1;
            QString str2;
            if (game->gamemap[clickPosRow][clickPosCol] == 1){
                str1 = "win";
                str2 = "go ahead!";
                QSound::play(WIN_SOUND);
            }
            else if (game->gamemap[clickPosRow][clickPosCol] == -1){
                str1 = "lose";
                str2 = "game over!";
                QSound::play(LOSE_SOUND);
            }
            QMessageBox::StandardButton btnValue = QMessageBox::information(this, "In game 2","you "+str1+" and "+
                                                                           str2);
 MW1 mw1;
            // 重置游戏状态，否则容易死循环
            if (btnValue == QMessageBox::Ok)    //此处改为晋级下一关
            {

                if(game->gamemap[clickPosRow][clickPosCol] == 1){
                    this->close();
//                    if(this->close()){
//                        mw1.show();
//                    }

                }
//                else {
//                   this->close();
//                }
            }
        }
    }

    // 判断死局
    if (game->isDeadGame())
    {
        QSound::play(LOSE_SOUND);
        QMessageBox::StandardButton btnValue = QMessageBox::information(this, "game2", "dead game!");
        if (btnValue == QMessageBox::Ok)
        {
            game->startGame();
            game->gameStatus = PLAYING;
        }

    }

}
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{   
    // 通过鼠标的hover确定落子的标记
    int x = event->x();
    int y = event->y();

    // 棋盘边缘不能落子
    if (x >= kBlockSize / 2 &&
            x < size().width() &&
            y >=kBlockSize / 2 &&
            y < size().height())
    {
        // 获取最近的左上角的点
        int col = x / kBlockSize;
        int row = y / kBlockSize;

        int leftTopPosX =kBlockSize * col;
        int leftTopPosY =kBlockSize * row;

        // 根据距离算出合适的点击位置,一共四个点，根据半径距离选最近的
        clickPosRow = -1; // 初始化最终的值
        clickPosCol = -1;
        int len = 0; // 计算完后取整

        // 确定一个误差在范围内的点，且只可能确定一个出来
        len = sqrt((x - leftTopPosX) * (x - leftTopPosX) + (y - leftTopPosY) * (y - leftTopPosY));
        if (len < kPosDelta)
        {
            clickPosRow = row+2;
            clickPosCol = col+2;
        }
        len = sqrt((x - leftTopPosX - kBlockSize) * (x - leftTopPosX - kBlockSize) + (y - leftTopPosY) * (y - leftTopPosY));
        if (len < kPosDelta)
        {
            clickPosRow = row+2;
            clickPosCol = col + 1+2;
        }
        len = sqrt((x - leftTopPosX) * (x - leftTopPosX) + (y - leftTopPosY - kBlockSize) * (y - leftTopPosY - kBlockSize));
        if (len < kPosDelta)
        {
            clickPosRow = row + 1+2;
            clickPosCol = col+2;
        }
        len = sqrt((x - leftTopPosX - kBlockSize) * (x - leftTopPosX - kBlockSize) + (y - leftTopPosY - kBlockSize) * (y - leftTopPosY - kBlockSize));
        if (len < kPosDelta)
        {
            clickPosRow = row + 1+2;
            clickPosCol = col + 1+2;
        }
    }
//    clickPosCol+=4;
//    clickPosRow+=4;
    // 存了坐标后也要重绘

    update();
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){
    //人下棋
    if (game->playerFlag)
    {
        chessOneByPerson();
        QTimer::singleShot(1000, this, SLOT(chessOneByAI()));
         // 用定时器做一个延迟
    }
}

void MainWindow::chessOneByPerson()
{
    // 根据当前存储的坐标下子
    // 只有有效点击才下子，并且该处没有子
    if (clickPosRow != -1 && clickPosCol != -1 && game->gamemap[clickPosCol][clickPosRow] == 0)
    {
        game->actionByPerson(clickPosCol, clickPosRow);
        QSound::play(CHESS_ONE_SOUND);

        // 重绘
        update();
    }
}

void MainWindow::chessOneByAI(){
    game->actionByAI();
    QSound::play(CHESS_ONE_SOUND);
    update();
}
